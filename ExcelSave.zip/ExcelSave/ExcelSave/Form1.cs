﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _Excel = Microsoft.Office.Interop.Excel;

namespace ExcelSave
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int rowindex = 0;
            //int columnindex = 0;
            try
            {
                FolderBrowserDialog folderDlg = new FolderBrowserDialog();
                DialogResult result = folderDlg.ShowDialog();

                if (result == DialogResult.OK)
                {
                    string folderpath = folderDlg.SelectedPath;
                    string folderfilename = folderpath + "\\test.xlsx";
                    MessageBox.Show("the file will be saved in path: " + folderfilename);

                    Microsoft.Office.Interop.Excel.Application wapp = new Microsoft.Office.Interop.Excel.Application();
                    Microsoft.Office.Interop.Excel.Worksheet wsheet;
                    Microsoft.Office.Interop.Excel.Workbook wbook;

                    wapp.Visible = false;

                    wbook = wapp.Workbooks.Add(true);
                    //wsheet = (Worksheet)wbook.ActiveSheet;
                    wbook.SaveAs(folderfilename, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                    false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    wbook.Close();

                    wapp.UserControl = true;
                    MessageBox.Show("File saved");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());

            }

    }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
